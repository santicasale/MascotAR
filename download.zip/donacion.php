<?php
session_start();
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Donar - MascotAR</title>
  <link rel="stylesheet" href="style.css">
  <link href="https://fonts.googleapis.com/css2?family=Amatic+SC:wght@700&family=Open+Sans:wght@400;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>

  <!-- Header -->
  <header>
    <div class="header-container">
      <div class="logo">
        <img src="imagenesong/logomascotar.png" alt="Logo MascotAR">
      </div>
      <nav>
        <ul>
          <li><a href="index.php">Inicio</a></li>
          <li>
            <a href="index.php#nosotros">Quiénes Somos</a>
            <ul class="submenu">
              <li><a href="prensa.html">Prensa</a></li>
            </ul>
          </li>
          <li><a href="donacion.php" class="active">Donar</a></li>
          <li><a href="adoptar.php">Adoptar</a></li>

          <?php if (isset($_SESSION['nick'])): ?>
            <li class="user-menu">
              <!-- Usuario logueado -->
              <a href="#"><i class="fas fa-user"></i> Hola, <?php echo htmlspecialchars($_SESSION['nick']); ?></a>
              <ul class="submenu">
                <?php if (!empty($_SESSION['admin']) && $_SESSION['admin'] == "SI"): ?>
                  <!-- Menú exclusivo para administradores -->
                  <li><a href="ver_usuarios.php">Gestión de usuarios</a></li>
                  <li><a href="ver_donaciones.php">Ver donaciones</a></li>
                  <li><a href="ver_adopciones.php">Ver adopciones</a></li>
                  <li><a href="ingreso_mascotas.php">Ingreso de mascotas</a></li>
                  <hr>
                <?php endif; ?>
                <li><a href="historial_donaciones.php">Historial de donaciones</a></li>
                <li><a href="historial_adopciones.php">Historial de adopciones</a></li>
                <li><a href="logout.php">Cerrar sesión</a></li>
              </ul>
            <?php else: ?>
              <!-- Usuario NO logueado -->
              <li class="user-menu">
                <a href="#"><i class="fas fa-user"></i></a>
                <ul class="submenu login-submenu">
                  <li>
                    <form class="login-form" action="login.php" method="post">
                      <h3>Iniciar sesión</h3>
                      <input type="email" name="email" placeholder="Ingrese su correo" required>
                      <input type="password" name="pass" placeholder="Ingrese su contraseña" required>
                      <button type="submit">Entrar</button>
                    </form>
                    <p class="register-link">
                      ¿No tenés cuenta? <a href="registrarse.php">Registrate</a>
                    </p>
                  </li>
              </ul>
            </li>
          <?php endif; ?>
        </ul>
      </nav>
    </div>
  </header>

  <!-- Sección Donar -->
  <section class="donar">
    <div class="donar-container">
      <h2>Tu donación nos ayuda a ayudar</h2>
      <p>
        Nuestro trabajo es imposible sin ayuda. 
        Te agradecemos desde ya tu voluntad de colaborar con nuestra misión 
        de encontrar hogares definitivos para nuestros rescatados, y también brindar un hogar digno a los que no tienen la suerte de ser adoptados. 
      </p>
      <p><strong>Gracias a tu donación podemos mantener activa esta ONG ❤️</strong></p>

      <div class="donar-grid">
        <!-- Formulario -->
        <div class="donar-form">
          <form id="donar-form" action="donar.php" method="post" enctype="multipart/form-data">
            <input type="text" name="nombre" placeholder="Tu nombre" >
            <input type="email" name="email" placeholder="Tu email" >
            <input type="number" name="monto" id="monto" placeholder="Monto a donar" required>
            
            <label for="alias"><strong>Alias para transferir:</strong></label>
            <div class="alias-box">
              <span>mascotar.donar</span>
              <img src="imagenesong/mp.webp" alt="Alias de transferencia">
            </div>

            <label for="comprobante"><strong>Adjuntar comprobante de transferencia:</strong></label>
            <input type="file" id="comprobante" name="comprobante" accept="image/*,application/pdf">
            <p id="archivo-nombre"></p>

            <button type="submit">Donar Ahora</button>
          </form>
        </div>

        <!-- Imagen -->
        <div class="donar-image">
          <img src="imagenesong/donar.jpg" alt="Imagen de donación">
        </div>
      </div>
    </div>
  </section>

  <!-- Footer -->
  <footer>
    <div class="footer-container">
      <div class="footer-logo">
        <img src="imagenesong/logomascotar.png" alt="Logo MascotAR">
      </div>
      <div class="footer-section">
        <h3>Contactos</h3>
        <p><strong>Junta Directiva:</strong> Juan Pérez</p>
        <p><strong>Tel:</strong> 11 8822 8844</p>
        <p><strong>Email:</strong> info@mascotar.ong</p>
      </div>
      <div class="footer-section">
        <h3>Dónde estamos</h3>
        <p>Nos encontramos en Pilar,<br>Provincia de Buenos Aires.</p>
      </div>
    </div>
  </footer>

  <!-- Script -->
  <script>
    // Mensaje de donación
    document.getElementById("donar-form").addEventListener("submit", function(event) {
      const monto = document.getElementById("monto").value;
      if (!monto || monto <= 0) {
        event.preventDefault();
        mostrarMensaje("⚠️ Por favor ingresá un monto válido.");
      } else {
        mostrarMensaje("🐾 ¡Gracias por tu donación! Redirigiendo a Mercado Pago...");
        // No bloqueamos el envío si el monto es válido
      }
    });

    function mostrarMensaje(texto) {
      const mensaje = document.createElement("div");
      mensaje.className = "mensaje-flotante";
      mensaje.innerText = texto;
      document.body.appendChild(mensaje);
      setTimeout(() => mensaje.classList.add("visible"), 100);
      setTimeout(() => {
        mensaje.classList.remove("visible");
        setTimeout(() => mensaje.remove(), 500);
      }, 5000);
    }

    // Mostrar nombre de archivo seleccionado
    const fileInput = document.getElementById("comprobante");
    const fileName = document.getElementById("archivo-nombre");

    fileInput.addEventListener("change", () => {
      if(fileInput.files.length > 0){
        fileName.textContent = `Archivo seleccionado: ${fileInput.files[0].name}`;
      } else {
        fileName.textContent = '';
      }
    });
  </script>

</body>
</html>
