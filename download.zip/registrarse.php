<?php
session_start();
// Si el usuario ya está logueado, lo redirigimos al inicio
if (isset($_SESSION['nick'])) {
    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Registrarse - MascotAR</title>
  <link rel="stylesheet" href="style.css">
  <link href="https://fonts.googleapis.com/css2?family=Amatic+SC:wght@700&family=Open+Sans:wght@400;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>

<header>
  <div class="header-container">
    <div class="logo">
      <img src="imagenesong/logomascotar.png" alt="Logo MascotAR">
    </div>
    <nav>
      <ul>
        <li><a href="index.php">Inicio</a></li>
        <li>
          <a href="index.php#nosotros">Quiénes Somos</a>
          <ul class="submenu">
            <li><a href="Prensa.php">Prensa</a></li>
          </ul>
        </li>
        <li><a href="donacion.php">Donar</a></li>
        <li><a href="Adoptar.php">Adoptar</a></li>
        <li class="user-menu">
          <a href="#"><i class="fas fa-user"></i></a>
          <ul class="submenu login-submenu">
            <li>
              <form class="login-form" action="login.php" method="post">
                <h3>Iniciar sesión</h3>
                <input type="email" name="email" placeholder="Ingrese su correo" required>
                <input type="password" name="pass" placeholder="Ingrese su contraseña" required>
                <button type="submit">Entrar</button>
              </form>
              <p class="register-link">
                ¿No tenés cuenta? <a href="registrarse.php">Registrate</a>
              </p>
            </li>
          </ul>
        </li>
      </ul>
    </nav>
  </div>
</header>

<section class="register">
  <div class="register-container">
    <div class="register-form">
      <h2>Crear cuenta</h2>

      <form action="registrar.php" method="post">
        <input type="text" name="f_name" placeholder="Nombre" required>
        <input type="text" name="l_name" placeholder="Apellido" required>
        <input type="text" name="nick" placeholder="Nombre de usuario" required>
        <input type="password" name="pass" placeholder="Contraseña" required>
        <input type="email" name="email" placeholder="Email" required>
        <input type="date" name="birthday" required>
        <input type="text" name="phone" placeholder="Telefono" required>
        <input type="text" name="domicilio" placeholder="domicilio" required>
        <button type="submit">Registrarme</button>
      </form>

      <p>¿Ya tenés cuenta? <a href="index.php">Iniciá sesión</a></p>
    </div>

    <div class="register-image">
      <img src="imagenesong/perrosgatos.jpg" alt="Registro MascotAR">
    </div>
  </div>
</section>

<footer>
  <div class="footer-container">
    <div class="footer-logo">
      <img src="imagenesong/logomascotar.png" alt="Logo MascotAR">
    </div>

    <div class="footer-section">
      <h3>Contactos</h3>
      <p><strong>Junta Directiva:</strong> Juan Pérez</p>
      <p><strong>Tel:</strong> 11 8822 8844</p>
      <p><strong>Email:</strong> info@mascotar.ong</p>
    </div>

    <div class="footer-section">
      <h3>Dónde estamos</h3>
      <p>Nos encontramos en Pilar,<br>Provincia de Buenos Aires.</p>
    </div>

   <div class="footer-section">
      <h3>Consultas</h3>
      <form action="procesar_consulta.php" method="post" class="footer-form">
        <input type="text" name="name" placeholder="Tu nombre" required>
        <input type="email" name="email" placeholder="Tu email" required>
        <textarea name="msg" placeholder="Tu mensaje" required></textarea>
        <button type="submit">Enviar</button>
      </form>
    </div>
  </div>
</footer>

</body>
</html>