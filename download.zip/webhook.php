<?php
include("conexion.php");

define('MP_ACCESS_TOKEN', 'APP_USR-502327826682038-100521-ae23557030dcf30365aa3fa312265775-2906214560');
require_once __DIR__ . '/vendor/autoload.php';

use MercadoPago\SDK;

SDK::setAccessToken(MP_ACCESS_TOKEN);

// Recibir contenido del webhook (JSON)
$data = file_get_contents("php://input");

if (!$data) {
    http_response_code(400);
    exit("Sin datos recibidos");
}

$event = json_decode($data, true);

// Solo procesar si es un pago
if (isset($event["type"]) && $event["type"] === "payment") {
    $payment_id = $event["data"]["id"];

    // Consultar pago en la API de Mercado Pago
    $ch = curl_init("https://api.mercadopago.com/v1/payments/$payment_id");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Authorization: Bearer " . MP_ACCESS_TOKEN
    ]);
    $response = curl_exec($ch);
    curl_close($ch);

    $payment = json_decode($response, true);

    if (isset($payment["status"]) && $payment["status"] === "approved") {
        $external_reference = intval($payment["external_reference"]);

        // Actualizar estado a 2 = aprobado
        $sql = "UPDATE donaciones SET donacion_status = 2 WHERE id_donacion = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $external_reference);
        $stmt->execute();
        $stmt->close();
        $conn->close();
    }
}

http_response_code(200);
exit("OK");
?>

